from django.shortcuts import render , redirect
from django.contrib.auth import login
from .forms import SignupForm , ChangeProfileForm , PasswordChanging
from django.urls import reverse_lazy
from django.views import generic
from django.contrib.auth.views import PasswordChangeView
from django.contrib.auth import views as auth_views
# Create your views here.

def register(request):
    if request.method != 'POST':
        #Display blank form
        form = SignupForm()
    
    else:
        #process completed form 
        form = SignupForm(data=request.POST)
        if form.is_valid():
            new_user = form.save()

            #Log the user in and then redirect to home page
            login(request,new_user)
            return redirect('recipe:home')
    
    #Display a blank or invalid form
    context = {'form': form}
    return render(request, 'registration/register.html' , context)

class UpdateProfile(generic.UpdateView):
    form_class = ChangeProfileForm
    template_name = "registration/edit_profile.html"
    success_url= reverse_lazy('recipe:profile')

    def get_object(self):
        return self.request.user
    
class PasswordChange(PasswordChangeView):
    form = "PasswordChanging"
    success_url = reverse_lazy('users:password_success')

def password_success(request):
    return render(request , 'registration/password_change_done.html')
                  
def delete_user(request):
    
    if request.method == 'POST':
        request.user.delete()
        return redirect('recipe:home')
   
    return render(request, 'registration/delete_account.html')

class MyPasswordResetView(auth_views.PasswordResetView):
    template_name = "registration/password_reset.html"
    email_template_name = "registration/password_reset_email.html"
    subject_template_name = "registration/password_reset_subject.txt"
    success_url = reverse_lazy("users:password_reset_done")


class MyPasswordResetDoneView(auth_views.PasswordResetDoneView):
    template_name = "registration/password_done.html"


class MyPasswordResetConfirmView(auth_views.PasswordResetConfirmView):
    template_name = "registration/password_confirm.html"
    success_url = reverse_lazy("users:password_reset_complete")


class MyPasswordResetCompleteView(auth_views.PasswordResetCompleteView):
    template_name = "registration/password_complete.html"