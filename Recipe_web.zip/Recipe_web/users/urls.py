from django.urls import path , include
from . import views
from django.contrib.auth import views as auth_views
app_name='users'

urlpatterns=[
    #Include defualt auth urls
    path("login/", auth_views.LoginView.as_view(template_name="registration/login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    #Register path
    path('register/', views.register , name='register'),
    path('edit_profile/', views.UpdateProfile.as_view(), name='edit_profile'),
    #Path for changing password
    path('change_password/' , views.PasswordChange.as_view(template_name='registration/password_change.html'),
         name='password_change'),
    path('password_success/', views.password_success, name='password_success'),
    # path to delete account 
    path('delete_account/', views.delete_user, name='delete_user'),
    #Path to reset 
   path("password_reset/", 
        views. MyPasswordResetView.as_view(), 
         name="password_reset"),

    path("password_reset_done/", 
         views.MyPasswordResetDoneView.as_view(), 
         name="password_reset_done"),

    path("reset/<uidb64>/<token>/", 
         views.MyPasswordResetConfirmView.as_view(), 
         name="password_reset_confirm"),

    path("password_reset_complete/", 
         views.MyPasswordResetCompleteView.as_view(), 
         name="password_reset_complete"),

]