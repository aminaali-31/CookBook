from django import forms
from django.contrib.auth.forms import UserCreationForm , UserChangeForm , PasswordChangeForm
from django.contrib.auth.models import User

class SignupForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'first_name','last_name','email', 'password1','password2']


class ChangeProfileForm(UserChangeForm):
    username = forms.CharField(max_length=150, widget=forms.TextInput(attrs={'placeholder': 'Change your username'}))
    first_name = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Change your first name'}))
    last_name = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Change your last name'}))
    email = forms.EmailField(max_length=150, widget=forms.EmailInput(attrs={'placeholder': 'Change your email'}))

    class Meta:
        model = User
        fields= ['username', 'first_name','last_name','email']


class PasswordChanging(PasswordChangeForm):
    class Meta:
        model = User
        fields = ['old_password', 'new_password1', 'new_password2']