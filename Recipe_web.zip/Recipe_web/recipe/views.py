from django.shortcuts import render , redirect , get_object_or_404
from .models import Recipe , Review
from .forms import RecipeForm , RatingForm , ContactForm
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden , HttpResponse
from django.core.mail import send_mail
from django.db.models import Count , Min ,Max ,Q
# Create your views here.



def home(request):
    recipes = Recipe.objects.all()
    return render(request, 'recipe/home.html', {'recipes': recipes})

def set_nav_color(request):
    if request.method == 'POST':
        color = request.POST.get('color')
        response = redirect('recipe:home')
        response.set_cookie(
            'nav_color',
            color,
            max_age=30*24*60*60
        )
        return response
    return HttpResponse("Tnvalid color")
def list(request):
    recipes = Recipe.objects.all()

    # Search by title
    search = request.GET.get('q')
    if search:
        recipes = recipes.filter(
            Q(title__icontains=search) | Q(ingredients__icontains=search)
        )

    # Filter by category
    category = request.GET.get('category')
    if category:
        recipes = recipes.filter(category=category)
    # Filter by max cooking time
    max_time = request.GET.get('max_time')
    if max_time:
        recipes = recipes.filter(cooktime__lte=max_time)
    #Filter by serving
    serving = request.GET.get('servings')
    if serving:
        recipes = recipes.filter(servings=serving)
    # Annotate with number of favorites
    recipes = recipes.annotate(num_favorites=Count('favorites'))

    # Sorting
    sort = request.GET.get('sort')
    if sort == 'favorites':
        recipes = recipes.order_by('-favorites')
    elif sort == 'time_asc':
        recipes = recipes.order_by('cooktime')
    elif sort == 'time_desc':
        recipes = recipes.order_by('-cooktime')

    # Slider min/max based on your dataset
    min_time = Recipe.objects.aggregate(Min('cooktime'))['cooktime__min'] or 5
    max_time_value = Recipe.objects.aggregate(Max('cooktime'))['cooktime__max'] or 180

    context = {
        'recipes': recipes,
        'query': search or '',
        'category': category or '',
        'max_time': max_time or max_time_value,
        'servings':serving or '',
        'sort': sort or '',
        'min_time': min_time,
        'max_time_value': max_time_value,
    }

    return render(request, 'recipe/home.html', context)

def recipe_detail(request,id):
    recipe = Recipe.objects.get(id=id)
    is_favorite = request.user in recipe.favorites.all()
    reviews = recipe.reviews.all()  # reverse relation via related_name
    # Calculate average rating
    if reviews.exists():
        average_rating = round(sum(r.rating for r in reviews) / reviews.count(), 1)
    else:
        average_rating = 0

    if request.method == 'POST':
        form = RatingForm(request.POST)
        if form.is_valid():
            # Either create a new review or update existing one by this user
            review, created = Review.objects.update_or_create(
                recipe=recipe,
                owner=request.user,
                defaults={
                    'rating': form.cleaned_data['rating'],
                    'comment': form.cleaned_data['comment']
                }
            )
             #Send email to recipe owner
            try:
                send_mail(
                subject=f"New comment on your recipe: {recipe.title}",
                message=f"""Hey {recipe.owner.username}, you have a new comment\n
                {request.user.username} commented: \n\n{review.comment}""",
                # from_email="enter your email here or leave blank. In case of blank email in settings will be used.",
                recipient_list=[recipe.owner.email],
                fail_silently=False
            )
            except Exception as e:
                print(e)
            return redirect('recipe:recipe_detail', id=recipe.id)
    else:
        # If user already has a review, prefill the form
        try:
            existing_review = Review.objects.get(recipe=recipe, owner=request.user)
            form = RatingForm(instance=existing_review)
        except Review.DoesNotExist:
            form = RatingForm()
    context = {
        'recipe': recipe,
        'reviews': reviews,
        'average_rating': average_rating,
        'is_favorite':is_favorite,
        'form': form,
    }
    return render(request, 'recipe/recipe.html', context)

@login_required
def add_recipe(request):
    if request.method == 'POST':
        form = RecipeForm(request.POST, request.FILES)
        if form.is_valid():
            recipe = form.save(commit=False)
            recipe.owner = request.user
            form.save()
            return redirect('recipe:home')  # change to your list page
    else:
        form = RecipeForm()

    return render(request, 'recipe/add_recipe.html', {'form': form})

@login_required
def profile(request):
      recipes=Recipe.objects.filter(owner=request.user)
      favorite_recipes = Recipe.objects.filter(favorites=request.user)
      username = request.user.username
      return render(request, 'recipe/profile.html' , {'recipes': recipes, 'name': username ,'favorites':favorite_recipes})   

@login_required
def edit_recipe(request,id):
    recipe= Recipe.objects.get(id=id)     
    if request.method != 'POST':
        form = RecipeForm(instance=recipe)
    #Post the submitted data
    else:
        form = RecipeForm(instance=recipe, data =request.POST , files=request.FILES)
        if form.is_valid():
            recipe = form.save(commit=False)
            recipe.owner = request.user
            form.save()
            return redirect('recipe:recipe_detail', id=id)  # change to your list page

    content = {'form': form, 'recipe': recipe}
    return render(request, 'recipe/edit_recipe.html' , context=content)


@login_required
def delete_recipe(request, id):
    recipe = get_object_or_404(Recipe, id=id)

    # Only allow the owner to delete
    if recipe.owner != request.user:
        return HttpResponseForbidden("You are not allowed to delete this recipe.")

    if request.method == "POST":
        recipe.delete()
        return redirect('recipe:profile')  # redirect to recipe list page
    
    return render(request, 'recipe/confirm_delete.html', {'recipe': recipe})

@login_required
def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['username']
            email = form.cleaned_data['email']
            message = form.cleaned_data['message']
            subject = form.cleaned_data['subject']

            # Send email
            send_mail(
                subject=subject,
                message=f'Name: {name}\nEmail: {email}\nMessage: {message}',
                from_email=email,  # From email
                #recipient_list=[email to receive user message],  # To email(s)
                fail_silently=False,
            )
            return redirect('recipe:success')  # Redirect to a success page
    else:
        form = ContactForm()
    return render(request, 'recipe/contact_form.html', {'form': form})

def success(request):
    return render(request, 'recipe/success.html')

@login_required
def toggle_favorite(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)

    if request.user in recipe.favorites.all():
        recipe.favorites.remove(request.user)
    else:
        recipe.favorites.add(request.user)

    return redirect(request.META.get('HTTP_REFERER', 'recipe:recipe_detail'))  # go back to same page