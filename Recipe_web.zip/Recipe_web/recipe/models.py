from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Recipe(models.Model):
    class choice(models.TextChoices):
           breakfast= '1', 'Breakfast'
           lunch= '2', 'Lunch'
           dinner= '3', 'Dinner'
           dessert='4', 'Dessert'
           beverage='5', 'Beverage'
           snack='6', 'Snacks'

    #Creating input  fields for different types of input data
    title =models.CharField(max_length=200)
    description = models.TextField("Give a brief description", null=True,blank=True)
    ingredients = models.TextField("Enter is this format item,qty. New item on next line.") 
    procedure=models.TextField(null=True, blank=True)
    cooktime=models.IntegerField("Enter time in minutes", default=1)
    servings=models.IntegerField("Enter the no. of serving", default=2)
    category = models.CharField(max_length=1,choices=choice.choices,default=choice.breakfast)
    images=models.ImageField(upload_to='recipes/', null=True, blank=True)
    favorites = models.ManyToManyField(User, related_name="favorite_recipes", blank=True)
    owner = models.ForeignKey(User, on_delete=models.CASCADE)

    #Class for grammar and some sorting
    class Meta:
        verbose_name = "Recipe"
        verbose_name_plural = "Recipes"
        ordering = ['-id']
        
    #return title as string(not necessary)
    def __str__(self):
        return self.title
    

    
class Review(models.Model):
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE, related_name="reviews")
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    rating = models.IntegerField(default=1)   # 1 to 5 stars
    comment = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
         unique_together = ('recipe' ,'owner') #Making sure one comment per user in a recipe