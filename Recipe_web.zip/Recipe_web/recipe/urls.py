"""Defines urls for recipe app"""
from django.urls import path
from . import views

app_name = 'recipe'

urlpatterns = [
    path('', views.home, name='home'),
    path('recipe/<int:id>/', views.recipe_detail ,name='recipe_detail' ),
    path('recipe/add_recipe/', views.add_recipe, name='add_recipe'),
    path('accounts/profile/', views.profile, name='profile'),
    path('edit_recipe/<int:id>/', views.edit_recipe, name='edit_recipe'),
    path('recipe/list/', views.list , name='list'),
    path('recipe/<int:id>/delete/', views.delete_recipe, name='delete_recipe'),
    path('contact/', views.contact_view , name='Contact'),
    path('success/' ,views.success, name='success'),
    path('recipe/<int:recipe_id>/favorite/', views.toggle_favorite, name='toggle_favorite'),
    path('nav_color/', views.set_nav_color, name='set_nav_color'),
]
