from django import forms
from .models import Recipe ,  Review

class RecipeForm(forms.ModelForm):
    class Meta:
        model = Recipe
        fields = ['title', 'description', 'ingredients', 'procedure', 'cooktime','servings', 'category', 'images']
        widgets = {
            'ingredients': forms.Textarea(attrs={
                'rows': 6,
                'cols': 40,
                'placeholder': 'Enter ingredients, one per line'
            }),
            'description': forms.Textarea(attrs={'rows': 3}),
            'procedure': forms.Textarea(attrs={'rows': 6}),
        }
    # Optional: clean to normalize line endings
    def clean_ingredients(self):
        data = self.cleaned_data.get('ingredients', '')
        
        # Normalize line endings
        lines = data.replace('\r\n', '\n').split('\n')
        
        # Strip whitespace from each line and remove empty lines
        cleaned_lines = [line.strip() for line in lines if line.strip()]
        
        # Join them back into a single string with newlines
        return '\n'.join(cleaned_lines)
    

class RatingForm(forms.ModelForm):
    class Meta:
        model = Review
        fields=['rating', 'comment']
        widgets={
            'comment': forms.Textarea(attrs={
                'rows': 2,
                'cols': 40
            }),
            'value': forms.NumberInput(attrs={'min': 1, 'max': 5}),
        }


class ContactForm(forms.Form):
    username= forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={'placeholder':'Enter your name'})
    )
    email = forms.EmailField(
        widget=forms.TextInput(attrs={"placeholder": "Enter your e-mail"})
    )
    subject = forms.CharField(widget=forms.TextInput(attrs={"placeholder": "Enter subject"}))
    message = forms.CharField(
        widget=forms.Textarea(attrs={"placeholder": "Enter your message"})
    )